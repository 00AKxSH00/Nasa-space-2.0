from flask import Flask, render_template
from flask import redirect

app= Flask(__name__)

@app.route("/home")
def home():
    return render_template("homepage.html")


@app.route("/")
def main():
    return render_template("homepage.html")


@app.route("/exo")
def exoplanet():
    return render_template("exoplanet.html")


@app.route("/Cancri_e/55")
def Cancri_e55():
    return render_template("55CancriE.html")


if __name__ == "__main__":
    app.run(debug=True)